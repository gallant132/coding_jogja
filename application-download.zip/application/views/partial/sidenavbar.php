<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav align-center">

                            
                            <a class="btn btn-warning text-black font-weight-bold" style="margin-top: 230px ;margin-right:30px ;margin-left: 30px" href="<?= base_url("admin") ?>">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-tachometer-alt"></i> Font Awesome fontawesome.com --></div>
                                Welcome
                            </a>
                            
                            

                            <a class="btn btn-warning text-black font-weight-bold" style="margin-top: 20px ;margin-right: 30px ;margin-left: 30px" href="https://codingjogja.000webhostapp.com/List_Pendaftar">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-table"></i> Font Awesome fontawesome.com --></div>
                                Data Pendaftar
                            </a>

                            <a class="btn btn-warning text-black font-weight-bold" style="margin-top: 20px ;margin-right: 30px ;margin-left: 30px" href="https://codingjogja.000webhostapp.com/Admin_kelas/tambah">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-chart-area"></i> Font Awesome fontawesome.com --></div>
                                Tambah Kelas
                            </a>


                            <a class="btn btn-warning text-black font-weight-bold" style="margin-top: 20px ;margin-right: 30px ;margin-left: 30px" href="https://codingjogja.000webhostapp.com/Admin_kelas/">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-chart-area"></i> Font Awesome fontawesome.com --></div>
                                Kelas
                            </a>

                            


                        </div>
                    </div>
</nav>