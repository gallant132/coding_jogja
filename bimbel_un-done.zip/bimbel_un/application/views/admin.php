<!DOCTYPE html>
<html lang="en">
    <head>
    <?php $this->load->view("partial/head.php") ?>
    </head>
    <body class="sb-nav-fixed">
        <!-- topnavbar -->
        <?php $this->load->view("partial/topnavbar.php") ?>

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <!-- sidenavbar -->
                <?php $this->load->view("partial/sidenavbar.php") ?>
            </div>

            <!-- isi -->
            <div id="layoutSidenav_content">
                <main>
                    
                <div class="d-flex align-items-center justify-content-center" style="height: 600px">
                    <h1> Welcome Admin </h1>
                </div>
                       
                </main>
                <!-- footer -->
                <?php $this->load->view("partial/footer.php") ?>
            </div>
        </div>

        <!-- js -->
        <?php $this->load->view("partial/js.php") ?>
        
    

</body>
</html>
