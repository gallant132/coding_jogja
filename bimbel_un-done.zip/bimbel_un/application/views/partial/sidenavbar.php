<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav align-center">

                            
                            <a class="btn btn-secondary text-white " style="margin-top: 230px ;margin-right: 10px ;margin-left: 10px" href="<?= base_url("admin") ?>">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-tachometer-alt"></i> Font Awesome fontawesome.com --></div>
                                Dashboard
                            </a>
                            

                            <a class="btn btn-secondary text-white" style="margin-top: 20px ;margin-right: 10px ;margin-left: 10px" href="http://localhost/bimbel_un/list_pendaftar">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-table"></i> Font Awesome fontawesome.com --></div>
                                Data Pendaftar
                            </a>

                            <a class="btn btn-secondary text-white " style="margin-top: 70px ;margin-right: 10px ;margin-left: 10px" href="http://localhost/bimbel_un/admin_kelas/tambah">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-chart-area"></i> Font Awesome fontawesome.com --></div>
                                Tambah Kelas
                            </a>


                            <a class="btn btn-secondary text-white" style="margin-top: 20px ;margin-right: 10px ;margin-left: 10px" href="http://localhost/bimbel_un/admin_kelas/">
                                <div class="sb-nav-link-icon"><!-- <i class="fas fa-chart-area"></i> Font Awesome fontawesome.com --></div>
                                Kelas
                            </a>

                            


                        </div>
                    </div>
</nav>