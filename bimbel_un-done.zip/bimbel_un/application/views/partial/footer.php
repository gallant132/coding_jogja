<footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-center small">
                            <div class="text-muted">copyright © 2020 coding jogja</div>
                        
                        </div>
                    </div>
</footer>